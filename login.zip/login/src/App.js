import "./styles.css";
import HomePage from "./HomePage";

export default function App() {
  return <div className="App">
    <h1>Hello Boya</h1>
    <HomePage/>
  </div>;
}
