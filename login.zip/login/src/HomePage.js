// Complete the HomePage Component and export it
import Form from "./Form";
function HomePage() {
  return (
    <div className="Homepage">
      <h1>HomePage</h1>  
      <Form/>
    </div>
  );
}
export default HomePage; 
